package com.amrita.jpl.cys21090.pract;

import javax.swing.*;
        import java.awt.*;



public class FormLayoutAnokha extends JFrame {

    public FormLayoutAnokha() {
        // Set the title and close operation

        setTitle("Anokha Form");
        setSize(40, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Labels
        JLabel label1 = new JLabel(" Full Name");
        JLabel label2 = new JLabel("Roll Number");
        JLabel label3 = new JLabel("College Mail id");
        JLabel label4 = new JLabel("Deperatment");

        // Buttons
        JButton button1 = new JButton("yuvaraj kumar");
        JButton button2 = new JButton("CB.EN.U4CYS21090");
        JButton button3 = new
                JButton("cb.en.u4cys21090@cb.students.amrita.edu");
        JButton button4 = new JButton("CYS");
        JButton button5 = new JButton("Submit");
        JTextField text1 = new JTextField();
        // Add components to the content pane

        add(text1);
        add(label1);
        add(button1);
        add(label2);
        add(button2);
        add(label3);
        add(button3);
        add(label4);
        add(button4);
        add(button5);

        // Make the window visible
        setVisible(true);
    }
    public static void main(String[] args) {
        new FormLayoutAnokha();
    }
}